/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Enable standalone output for Docker deployment
  output: 'standalone',
  // Optimize images for production
  images: {
    unoptimized: process.env.NODE_ENV === 'development',
  },
  experimental: {
    turbopack: {
      // Prevent Next from inferring a parent workspace root (multiple lockfiles)
      root: __dirname,
    },
  },
};

module.exports = nextConfig;
