/**
 * Supabase Database Types (Project-local)
 *
 * Provides a stable, exported `Database` type for supabase-js.
 * Keep this file as the single source of truth for typing Supabase clients.
 *
 * IMPORTANT:
 * - Do NOT import { Database } from "@/types/supabase" inside this file (self-import).
 * - This file must export Database for supabase typings to work.
 */

import type {
  Sprint,
  Story,
  AcceptanceCriterion,
  Task,
  Comment,
  CrewWorkload,
} from "./sprint";

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

// RBAC / core domain types (kept light; extend as schema evolves)
export type SystemRole = "administrator" | "owner" | "developer" | "viewer";

export interface AuthProfileRow {
  id: string;
  email: string;
  display_name: string | null;
  system_role: SystemRole;
  created_at: string;
  updated_at?: string;
}

export interface ProjectRow {
  id: string;
  name: string;
  description?: string | null;
  owner_id: string;
  status?: string | null;
  tags?: string[] | null;
  created_at: string;
  updated_at?: string;
}

export interface RoleRow {
  id: string;
  name: string;
  description?: string | null;
  permissions?: string[] | null;
}

export interface ProjectMemberRow {
  id: string;
  project_id: string;
  user_id: string;
  role_id: string;
  invited_by: string | null;
  joined_at: string;
}

export interface AuditLogRow {
  id: string;
  user_id: string | null;
  action: string;
  resource_type: string;
  resource_id: string | null;
  details: Json | null;
  created_at: string;
}

export interface ApiKeyRow {
  id: string;
  user_id: string;
  name: string;
  key_hash: string;
  last_used_at: string | null;
  created_at: string;
}

// Insert/Update conventions
export type SprintInsert =
  Omit<Sprint, "id" | "created_at" | "updated_at"> & {
    id?: string;
    created_at?: string;
    updated_at?: string;
  };

export type SprintUpdate = Partial<Omit<Sprint, "id" | "created_at">> & {
  id?: string;
  created_at?: string;
};

export type StoryInsert =
  Omit<Story, "id" | "created_at" | "updated_at"> & {
    id?: string;
    created_at?: string;
    updated_at?: string;
  };

export type StoryUpdate = Partial<Omit<Story, "id" | "created_at">> & {
  id?: string;
  created_at?: string;
};

export type AcceptanceCriterionInsert = Omit<AcceptanceCriterion, "id"> & {
  id?: string;
};
export type AcceptanceCriterionUpdate = Partial<Omit<AcceptanceCriterion, "id">> & {
  id?: string;
};

export type TaskInsert = Omit<Task, "id"> & { id?: string };
export type TaskUpdate = Partial<Omit<Task, "id">> & { id?: string };

export type CommentInsert = Omit<Comment, "id"> & { id?: string };
export type CommentUpdate = Partial<Omit<Comment, "id">> & { id?: string };

export type CrewWorkloadInsert = Omit<CrewWorkload, "id"> & { id?: string };
export type CrewWorkloadUpdate = Partial<Omit<CrewWorkload, "id">> & { id?: string };

// Orchestration / memory helper tables (referenced by patches)
export interface CrewActionRow {
  id: string;
  crew_member: string;
  action_type: string | null;
  description: string;
  created_at: string;
  metadata?: Json | null;
}
export type CrewActionInsert = Omit<CrewActionRow, "id" | "created_at"> & {
  id?: string;
  created_at?: string;
};
export type CrewActionUpdate = Partial<Omit<CrewActionRow, "id">> & { id?: string };

export interface SprintPlanningMemoryRow {
  id: string;
  project_id: string | null;
  goals: string;
  summary: string | null;
  crew_involvement: Json | null;
  outcome: string | null;
  created_at: string;
}
export type SprintPlanningMemoryInsert = Omit<SprintPlanningMemoryRow, "id" | "created_at"> & {
  id?: string;
  created_at?: string;
};
export type SprintPlanningMemoryUpdate = Partial<Omit<SprintPlanningMemoryRow, "id">> & { id?: string };

export type Database = {
  public: {
    Tables: {
      auth_profiles: { Row: AuthProfileRow; Insert: Partial<AuthProfileRow>; Update: Partial<AuthProfileRow>; Relationships: [] };
      projects: { Row: ProjectRow; Insert: Partial<ProjectRow>; Update: Partial<ProjectRow>; Relationships: [] };
      roles: { Row: RoleRow; Insert: RoleRow; Update: Partial<RoleRow>; Relationships: [] };
      project_members: { Row: ProjectMemberRow; Insert: Partial<ProjectMemberRow>; Update: Partial<ProjectMemberRow>; Relationships: [] };
      audit_log: { Row: AuditLogRow; Insert: Partial<AuditLogRow>; Update: Partial<AuditLogRow>; Relationships: [] };
      api_keys: { Row: ApiKeyRow; Insert: Partial<ApiKeyRow>; Update: Partial<ApiKeyRow>; Relationships: [] };

      sprints: { Row: Sprint; Insert: SprintInsert; Update: SprintUpdate; Relationships: [] };
      stories: { Row: Story; Insert: StoryInsert; Update: StoryUpdate; Relationships: [] };
      acceptance_criteria: { Row: AcceptanceCriterion; Insert: AcceptanceCriterionInsert; Update: AcceptanceCriterionUpdate; Relationships: [] };
      tasks: { Row: Task; Insert: TaskInsert; Update: TaskUpdate; Relationships: [] };
      comments: { Row: Comment; Insert: CommentInsert; Update: CommentUpdate; Relationships: [] };
      crew_workload: { Row: CrewWorkload; Insert: CrewWorkloadInsert; Update: CrewWorkloadUpdate; Relationships: [] };

      crew_actions: { Row: CrewActionRow; Insert: CrewActionInsert; Update: CrewActionUpdate; Relationships: [] };
      sprint_planning_memories: { Row: SprintPlanningMemoryRow; Insert: SprintPlanningMemoryInsert; Update: SprintPlanningMemoryUpdate; Relationships: [] };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
    Enums: Record<string, never>;
    CompositeTypes: Record<string, never>;
  };
};

export type PublicSchema = Database["public"];
export type Tables = PublicSchema["Tables"];
export type TableRow<T extends keyof Tables> = Tables[T]["Row"];
export type TableInsert<T extends keyof Tables> = Tables[T]["Insert"];
export type TableUpdate<T extends keyof Tables> = Tables[T]["Update"];
