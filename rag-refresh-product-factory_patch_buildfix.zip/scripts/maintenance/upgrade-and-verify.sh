#!/usr/bin/env bash
set -euo pipefail

ZIP="${1:-}"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT_DIR"

say(){ printf "%b\n" "$*"; }
ok(){ say "✅ $*"; }
warn(){ say "⚠️  $*"; }
err(){ say "❌ $*"; exit 1; }

command -v unzip >/dev/null 2>&1 || err "unzip required"
command -v node  >/dev/null 2>&1 || err "node required"
command -v npm   >/dev/null 2>&1 || err "npm required"

[[ -n "$ZIP" ]] || err "Usage: bash scripts/maintenance/upgrade-and-verify.sh <patch.zip>"
[[ -f "$ZIP" ]] || err "Patch zip not found: $ZIP"

# Refuse junk/cache artifacts
if unzip -Z1 "$ZIP" | grep -E '(^|/)(\.git/|node_modules/|\.next/|dist/|build/|coverage/|__MACOSX/)' >/dev/null 2>&1; then
  err "Patch zip contains build/cache artifacts. Refusing."
fi

ok "Applying patch overlay: $ZIP"
unzip -o "$ZIP" >/dev/null
ok "Patch overlay applied."

# Always clear stale Next build output (prevents ENOTEMPTY chunks 2 issues)
if [[ -d ".next" ]]; then
  warn "Removing stale .next build output..."
  rm -rf .next
fi

run_if_script_exists() {
  local dir="$1"; local script="$2"
  if [[ "$dir" == "." ]]; then
    [[ -f "package.json" ]] || return 0
    node -e "const p=require('./package.json');process.exit(p.scripts && p.scripts['$script']?0:1)" >/dev/null 2>&1 && {
      ok "npm run $script"
      npm run "$script"
      return 0
    }
    warn "No script '$script' in root package.json (skipping)"
    return 0
  fi

  if [[ -f "$dir/package.json" ]]; then
    node -e "const p=require('./$dir/package.json');process.exit(p.scripts && p.scripts['$script']?0:1)" >/dev/null 2>&1 && {
      ok "npm -C $dir run $script"
      npm -C "$dir" run "$script"
      return 0
    }
  fi
  warn "No script '$script' in $dir/package.json (skipping)"
  return 0
}

# Optional hardening
if [[ -f "scripts/maintenance/fix-utf8-base64-and-verify.sh" ]]; then
  ok "Running UTF-8 base64 hardening…"
  bash scripts/maintenance/fix-utf8-base64-and-verify.sh --apply
fi

if [[ -f "package.json" ]]; then
  ok "Installing root deps…"
  npm install
  run_if_script_exists "." "scripts:check" || true
  run_if_script_exists "." "check:env" || true
  run_if_script_exists "." "lint" || true
  run_if_script_exists "." "typecheck" || true
  run_if_script_exists "." "build" || true
else
  warn "No root package.json found (skipping install/build)"
fi

if [[ -d "vscode-extension" && -f "vscode-extension/package.json" ]]; then
  ok "Installing vscode-extension deps…"
  npm -C vscode-extension install || true
  run_if_script_exists "vscode-extension" "lint" || true
  run_if_script_exists "vscode-extension" "typecheck" || true
  run_if_script_exists "vscode-extension" "build" || true
fi

ok "Upgrade + verification complete."
