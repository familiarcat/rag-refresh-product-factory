import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '@/types/supabase';

let _client: SupabaseClient<Database> | null = null;

/**
 * Server-side Supabase client.
 * Prefers SERVICE ROLE key (server-only). Falls back to ANON key if needed.
 *
 * Required env:
 *  - SUPABASE_URL (or NEXT_PUBLIC_SUPABASE_URL)
 *  - SUPABASE_SERVICE_ROLE_KEY (preferred) or SUPABASE_ANON_KEY
 */
export function getSupabaseServer(): SupabaseClient<Database> {
  if (_client) return _client;

  const url = process.env.SUPABASE_URL ?? process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key =
    process.env.SUPABASE_SERVICE_ROLE_KEY ??
    process.env.SUPABASE_SERVICE_ROLE ??
    process.env.SUPABASE_ANON_KEY ??
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url) throw new Error('Missing SUPABASE_URL (or NEXT_PUBLIC_SUPABASE_URL)');
  if (!key) {
    throw new Error('Missing SUPABASE_SERVICE_ROLE_KEY (preferred) or SUPABASE_ANON_KEY');
  }

  _client = createClient<Database>(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  return _client;
}

export const supabaseServer = getSupabaseServer();
