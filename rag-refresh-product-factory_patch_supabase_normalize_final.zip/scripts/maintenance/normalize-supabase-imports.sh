#!/usr/bin/env bash
set -euo pipefail

echo "🔧 Normalizing Supabase imports (canonical fix)"

ROOT="$(pwd)"
LIB_DIR="$ROOT/lib/supabase"

echo "📁 Ensuring canonical lib/supabase structure..."
mkdir -p "$LIB_DIR"

# 1) Canonical server client
cat > "$LIB_DIR/server.ts" <<'EOF'
import { createClient } from '@supabase/supabase-js'
import type { Database } from '@/types/supabase'

export const supabaseServer = createClient<Database>(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)
EOF

# 2) Canonical browser client
cat > "$LIB_DIR/browser.ts" <<'EOF'
import { createClient } from '@supabase/supabase-js'
import type { Database } from '@/types/supabase'

export const supabaseBrowser = createClient<Database>(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)
EOF

# 3) Public barrel export
cat > "$LIB_DIR/index.ts" <<'EOF'
export { supabaseServer } from './server'
export { supabaseBrowser } from './browser'
EOF

# 4) Remove legacy / duplicate files
echo "🧹 Removing legacy Supabase files..."
rm -f "$ROOT/lib/supabase.ts" || true
rm -f "$ROOT/lib/supabase-server.ts" || true
rm -f "$ROOT/lib/supabase-browser.ts" || true
rm -f "$ROOT/lib/supabase 2.ts" || true

# 5) Hard-fail if illegal imports still exist
echo "🔍 Scanning for illegal Supabase imports..."
BAD_IMPORTS="$(rg "@/lib/supabase-server|@/lib/supabase-browser" . || true)"

if [[ -n "$BAD_IMPORTS" ]]; then
  echo "❌ Found illegal Supabase imports (must be updated):"
  echo "$BAD_IMPORTS"
  echo ""
  echo "➡️ Replace them with one of:"
  echo "   import { supabaseServer } from '@/lib/supabase'"
  echo "   import { supabaseBrowser } from '@/lib/supabase'"
  exit 1
fi

echo "✅ Supabase import normalization complete"
