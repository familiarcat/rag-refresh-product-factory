/**
 * Canonical Supabase exports for the project.
 *
 * Goal:
 * - Provide explicit server vs browser clients.
 * - Keep backward compatibility for older imports that expect:
 *   - `supabase`
 *   - `checkPermission`
 *   - `logAudit`
 *   - `AuthProfile`
 *   - `ApiKey`
 *
 * IMPORTANT:
 * - Prefer importing `supabaseServer` or `supabaseBrowser` from '@/lib/supabase'.
 */

import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '@/types/supabase';

export type { Database };

/** Back-compat placeholder types (kept minimal to avoid cyclic imports). */
export type AuthProfile = Record<string, unknown>;
export type ApiKey = Record<string, unknown>;

/** Internal helpers */
function getEnvRequired(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var: ${name}`);
  return v;
}
function getEnvOptional(name: string): string | undefined {
  return process.env[name] || undefined;
}

function createServiceClient(): SupabaseClient<Database> {
  const url = getEnvRequired('SUPABASE_URL');
  // Prefer service role key for server usage; fall back to anon for dev.
  const key = getEnvOptional('SUPABASE_SERVICE_ROLE_KEY') ?? getEnvRequired('SUPABASE_ANON_KEY');
  return createClient<Database>(url, key, {
    auth: { persistSession: false },
  });
}

function createBrowserClient(): SupabaseClient<Database> {
  const url = getEnvOptional('NEXT_PUBLIC_SUPABASE_URL') ?? getEnvRequired('SUPABASE_URL');
  const key = getEnvOptional('NEXT_PUBLIC_SUPABASE_ANON_KEY') ?? getEnvRequired('SUPABASE_ANON_KEY');
  return createClient<Database>(url, key, {
    auth: { persistSession: true },
  });
}

/**
 * Server-side Supabase client (service role when available).
 * Use in Route Handlers / server actions / scripts.
 */
export const supabaseServer: SupabaseClient<Database> = createServiceClient();

/**
 * Browser-side Supabase client (anon key).
 * Use in client components.
 */
export const supabaseBrowser: SupabaseClient<Database> = createBrowserClient();

/** Backward-compatible alias used across older code paths. */
export const supabase: SupabaseClient<Database> = supabaseServer;

/**
 * Permission check helper (RPC-based).
 * Returns boolean, never throws (returns false on error).
 */
export async function checkPermission(args: {
  userId: string;
  permission: string;
  projectId?: string | null;
}): Promise<boolean> {
  try {
    const { userId, permission, projectId = null } = args;
    const { data, error } = await supabaseServer.rpc('check_permission' as any, {
      p_user_id: userId,
      p_permission: permission,
      p_project_id: projectId,
    } as any);

    if (error) return false;
    return Boolean(data);
  } catch {
    return false;
  }
}

/**
 * Lightweight audit logger.
 * If an `audit_logs` table exists, we attempt to insert; otherwise no-op.
 */
export async function logAudit(event: {
  action: string;
  actorId?: string | null;
  projectId?: string | null;
  metadata?: Record<string, unknown>;
}): Promise<void> {
  try {
    const payload = {
      action: event.action,
      actor_id: event.actorId ?? null,
      project_id: event.projectId ?? null,
      metadata: event.metadata ?? {},
      created_at: new Date().toISOString(),
    };

    // Use `as any` to avoid coupling to generated table types.
    await supabaseServer.from('audit_logs' as any).insert(payload as any);
  } catch {
    // swallow (audit logging must not break app routes)
  }
}

/**
 * Health helpers used by dev utilities.
 */
export async function checkSupabaseConnection(): Promise<{ ok: boolean; error?: string }> {
  try {
    // Cheap query; will fail gracefully if RPC doesn't exist.
    const { error } = await supabaseServer.rpc('version' as any, {} as any);
    if (!error) return { ok: true };
    return { ok: false, error: error.message };
  } catch (e: any) {
    return { ok: false, error: e?.message ?? String(e) };
  }
}

export async function getDatabaseStats(): Promise<Record<string, unknown>> {
  // Placeholder – extend if/when you have a stats view or RPC.
  return { timestamp: new Date().toISOString() };
}
