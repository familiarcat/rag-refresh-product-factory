// Back-compat: some codebases used '@/lib/supabase' as a file.
// Prefer importing from '@/lib/supabase' (folder) going forward.
export * from './supabase';
