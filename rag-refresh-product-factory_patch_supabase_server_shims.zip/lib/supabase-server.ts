// Compatibility shim: older code imports from '@/lib/supabase-server'
export { supabaseServer as supabase, supabaseServer, checkPermission, logAudit, type AuthProfile } from '@/lib/supabase';
export { checkSupabaseConnection, getDatabaseStats } from '@/lib/supabase';
