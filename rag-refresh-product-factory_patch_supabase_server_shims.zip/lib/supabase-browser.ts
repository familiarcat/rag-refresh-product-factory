// Compatibility shim: older code imports from '@/lib/supabase-browser'
export { supabaseBrowser, type Database } from '@/lib/supabase';
