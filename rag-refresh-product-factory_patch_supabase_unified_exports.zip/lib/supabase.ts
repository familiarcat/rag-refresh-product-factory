/**
 * Unified Supabase entrypoint (server + browser) with legacy compatibility exports.
 *
 * Canonical usage:
 *   - Server (App Routes / server utilities): import { supabaseServer } from '@/lib/supabase'
 *   - Browser (client components):           import { supabaseBrowser } from '@/lib/supabase'
 *
 * Legacy compatibility (avoid in new code):
 *   import { supabase, checkPermission, logAudit, AuthProfile } from '@/lib/supabase'
 */

import type { SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '@/types/supabase';

// These should already exist in the repo (created by prior patches). If not, create them.
import { supabaseServer } from './supabase-server';
import { supabaseBrowser } from './supabase-browser';

export { supabaseServer, supabaseBrowser };

/**
 * Legacy alias: historically many files imported `{ supabase }` from '@/lib/supabase'
 * In this codebase, those usages are server-side (App Routes / middleware), so we map to supabaseServer.
 */
export const supabase: SupabaseClient<Database> = supabaseServer;

/**
 * Minimal AuthProfile shape used across auth middleware.
 * Extend as needed without breaking callers.
 */
export type AuthProfile = {
  user_id: string;
  email?: string | null;
  role?: string | null;
  is_active?: boolean | null;
  [key: string]: unknown;
};

/**
 * Permission check helper.
 * Tries the `check_permission` RPC first (preferred). Falls back to false on any error.
 *
 * Expected RPC signature (typical):
 *   check_permission(p_user_id uuid/text, p_permission text, p_project_id uuid/text|null) -> boolean
 */
export async function checkPermission(
  userId: string,
  permission: string,
  projectId?: string | null
): Promise<boolean> {
  try {
    const { data, error } = await supabaseServer.rpc('check_permission', {
      p_user_id: userId,
      p_permission: permission,
      p_project_id: projectId ?? null,
    } as any);

    if (error) return false;

    if (typeof data === 'boolean') return data;

    // Some RPCs return objects like { allowed: true }
    if (data && typeof (data as any).allowed === 'boolean') return (data as any).allowed;

    return !!data;
  } catch {
    return false;
  }
}

/**
 * Audit logging helper.
 * Attempts `log_audit` RPC if present; otherwise becomes a safe no-op that returns true.
 *
 * If you have an `audit_log` table instead of an RPC, wire it here later.
 */
export async function logAudit(params: {
  userId: string;
  action: string;
  resource?: string | null;
  projectId?: string | null;
  meta?: Record<string, unknown> | null;
}): Promise<boolean> {
  try {
    const { error } = await supabaseServer.rpc('log_audit', {
      p_user_id: params.userId,
      p_action: params.action,
      p_resource: params.resource ?? null,
      p_project_id: params.projectId ?? null,
      p_meta: params.meta ?? null,
    } as any);

    // If the RPC doesn't exist, Supabase will return an error. Treat as non-fatal for build.
    if (error) return true;
    return true;
  } catch {
    return true;
  }
}
