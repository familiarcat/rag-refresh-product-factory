import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '@/types/supabase';

/**
 * Shared Supabase client (server-safe if you only use it in server contexts).
 * Prefer importing `supabaseServer` from '@/lib/supabase-server' in route handlers,
 * and `supabaseBrowser` from '@/lib/supabase-browser' in client components.
 */
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.SUPABASE_URL;
const supabaseAnonKey =
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  // Don't throw at module load in Next.js (can break tooling); callers will see runtime error.
  // eslint-disable-next-line no-console
  console.warn('⚠️  Missing SUPABASE URL/ANON KEY env vars. Supabase client will not work until set.');
}

/** Global client (typed) */
export const supabase: SupabaseClient<Database> = createClient<Database>(
  supabaseUrl || 'http://localhost:54321',
  supabaseAnonKey || 'invalid-key',
);

/**
 * Types used by auth + API key middleware
 */
export type ApiKey = Database['public']['Tables']['api_keys']['Row'];

export type AuthProfile = Database['public']['Tables']['auth_profiles']['Row'] & {
  /** Optional computed permission list */
  permissions?: string[] | null;
};

/**
 * RPC helper: check whether a user has a permission within a project.
 * Requires a Postgres function: check_permission(p_user_id uuid, p_permission text, p_project_id uuid) returns boolean.
 */
export async function checkPermission(args: {
  userId: string;
  permission: string;
  projectId: string;
}): Promise<boolean> {
  const { data, error } = await supabase.rpc('check_permission', {
    p_user_id: args.userId,
    p_permission: args.permission,
    p_project_id: args.projectId,
  });

  if (error) {
    // eslint-disable-next-line no-console
    console.warn('checkPermission RPC error:', error);
    return false;
  }

  return Boolean(data);
}

/**
 * RPC helper: log audit events.
 * Requires a Postgres function: log_audit(p_user_id uuid, p_action text, p_resource text, p_metadata jsonb) returns void.
 */
export async function logAudit(args: {
  userId: string;
  action: string;
  resource: string;
  metadata?: Record<string, unknown>;
}): Promise<void> {
  const { error } = await supabase.rpc('log_audit', {
    p_user_id: args.userId,
    p_action: args.action,
    p_resource: args.resource,
    p_metadata: args.metadata ?? {},
  });

  if (error) {
    // eslint-disable-next-line no-console
    console.warn('logAudit RPC error:', error);
  }
}
