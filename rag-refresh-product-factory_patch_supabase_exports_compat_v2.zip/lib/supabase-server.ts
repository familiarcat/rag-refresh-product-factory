import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '@/types/supabase';

/**
 * Server-side Supabase client.
 * Uses service-role key when available (recommended for server routes),
 * falling back to anon key.
 */
const supabaseUrl = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey =
  process.env.SUPABASE_SERVICE_ROLE_KEY ||
  process.env.SUPABASE_ANON_KEY ||
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

export const supabaseServer: SupabaseClient<Database> = createClient<Database>(
  supabaseUrl || 'http://localhost:54321',
  supabaseKey || 'invalid-key',
);

// Backwards-compat: many routes import `{ supabase } from "@/lib/supabase-server"`
export const supabase = supabaseServer;
export default supabaseServer;
