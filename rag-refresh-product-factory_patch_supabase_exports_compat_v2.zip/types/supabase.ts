/* eslint-disable @typescript-eslint/no-explicit-any */
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export type Database = {
  public: {
    Tables: {
      crew_actions: {
        Row: {
          id: string;
          crew_member: string;
          action_type: string | null;
          description: string | null;
          outcome: string | null;
          context: Json | null;
          success_score: number | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          crew_member: string;
          action_type?: string | null;
          description?: string | null;
          outcome?: string | null;
          context?: Json | null;
          success_score?: number | null;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['crew_actions']['Insert']>;
        Relationships: [];
      };

      sprint_planning_memories: {
        Row: {
          id: string;
          sprint_id: string;
          project_id: string;
          project_name: string;
          goals: string[] | null;
          crew_assignments: Json | null;
          velocity_target: number | null;
          velocity_actual: number | null;
          picard_analysis: string | null;
          riker_organization: string | null;
          quark_optimization: string | null;
          created_at: string;
          updated_at: string | null;
        };
        Insert: {
          id?: string;
          sprint_id: string;
          project_id: string;
          project_name: string;
          goals?: string[] | null;
          crew_assignments?: Json | null;
          velocity_target?: number | null;
          velocity_actual?: number | null;
          picard_analysis?: string | null;
          riker_organization?: string | null;
          quark_optimization?: string | null;
          created_at?: string;
          updated_at?: string | null;
        };
        Update: Partial<Database['public']['Tables']['sprint_planning_memories']['Insert']>;
        Relationships: [];
      };

      api_keys: {
        Row: {
          id: string;
          user_id: string;
          project_id: string | null;
          name: string;
          key_hash: string;
          key_prefix: string | null;
          permissions: string[] | null;
          expires_at: string | null;
          last_used_at: string | null;
          revoked_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          project_id?: string | null;
          name: string;
          key_hash: string;
          key_prefix?: string | null;
          permissions?: string[] | null;
          expires_at?: string | null;
          last_used_at?: string | null;
          revoked_at?: string | null;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['api_keys']['Insert']>;
        Relationships: [];
      };

      auth_profiles: {
        Row: {
          id: string;
          user_id: string;
          project_id: string | null;
          roles: string[] | null;
          permissions: string[] | null;
          revoked_at: string | null;
          created_at: string;
          updated_at: string | null;
        };
        Insert: {
          id?: string;
          user_id: string;
          project_id?: string | null;
          roles?: string[] | null;
          permissions?: string[] | null;
          revoked_at?: string | null;
          created_at?: string;
          updated_at?: string | null;
        };
        Update: Partial<Database['public']['Tables']['auth_profiles']['Insert']>;
        Relationships: [];
      };
    };

    Functions: {
      check_permission: {
        Args: {
          p_user_id: string;
          p_permission: string;
          p_project_id: string;
        };
        Returns: boolean;
      };
      log_audit: {
        Args: {
          p_user_id: string;
          p_action: string;
          p_resource: string;
          p_metadata: Json;
        };
        Returns: null;
      };
    };

    Enums: Record<string, never>;
    CompositeTypes: Record<string, never>;
    Views: Record<string, never>;
  };
};
