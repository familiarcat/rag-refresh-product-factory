#!/usr/bin/env bash
set -euo pipefail

say(){ printf "%b\n" "$*"; }
ok(){ say "✅ $*"; }
warn(){ say "⚠️  $*"; }

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.. && pwd)"
cd "$ROOT"

ok "Normalizing Supabase imports (portable: uses perl)..."

# 1) Rewrite legacy '@/lib/supabase' -> '@/lib/supabase-server'
#    (handles both single and double quotes)
perl -pi -e "s@from\s+['\"]@/lib/supabase['\"]@from '@/lib/supabase-server'@g" $(rg -l "from ['\"]@/lib/supabase['\"]" . || true) 2>/dev/null || true
perl -pi -e 's@from\s+"@/lib/supabase"@from "@/lib/supabase-server"@g' $(rg -l 'from "@/lib/supabase"' . || true) 2>/dev/null || true

# 2) Normalize aliased imports: { supabaseServer as supabase } -> { supabase }
#    Handles both quoted module strings.
perl -pi -e "s/import\s*\{\s*supabaseServer\s+as\s+supabase\s*\}/import { supabase }/g" $(rg -l "supabaseServer\s+as\s+supabase" . || true) 2>/dev/null || true

ok "Done. Quick report:"
rg -n "from ['\"]@/lib/supabase['\"]" . || true
rg -n "supabaseServer\s+as\s+supabase" . || true

ok "Supabase import normalization complete."
