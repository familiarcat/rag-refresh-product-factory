#!/usr/bin/env bash
set -euo pipefail

say(){ printf "%b\n" "$*"; }
ok(){ say "✅ $*"; }
warn(){ say "⚠️  $*"; }

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.. && pwd)"
cd "$ROOT"

ok "Normalizing Supabase imports (portable; no sed; safe quoting)..."

# Helper: apply a perl rewrite to a list of files coming from ripgrep.
apply_perl_to_rg_files() {
  local rg_pattern="$1"
  local perl_expr="$2"

  # ripgrep may return nothing; keep it non-fatal
  if ! command -v rg >/dev/null 2>&1; then
    warn "rg (ripgrep) not found; skipping: $rg_pattern"
    return 0
  fi

  rg -l --glob '!*node_modules/*' --glob '!*.next/*' --glob '!.trash/*' "$rg_pattern" . 2>/dev/null \
    | while IFS= read -r f; do
        # skip if file vanished
        [[ -f "$f" ]] || continue
        perl -0777 -pi -e "$perl_expr" "$f"
      done
}

# 1) Any imports from "@/lib/supabase" should become "@/lib/supabase-server"
apply_perl_to_rg_files "from ['\"]@/lib/supabase['\"]" \
  's/from\s+([\"\x27])@\/lib\/supabase\1/from \1@\/lib\/supabase-server\1/g'

# 2) Normalize alias form: import { supabaseServer as supabase } from "@/lib/supabase-server";
apply_perl_to_rg_files "supabaseServer\s+as\s+supabase" \
  's/import\s*\{\s*supabaseServer\s+as\s+supabase\s*\}/import { supabase }/g'

# 3) If any file imports from "./supabase" within lib/ (bad local path), leave a report (don’t auto-change)
ok "Quick report (remaining matches that may need manual review):"
rg -n --glob '!*node_modules/*' --glob '!*\.next/*' --glob '!.trash/*' "from ['\"]@/lib/supabase['\"]" . || true
rg -n --glob '!*node_modules/*' --glob '!*\.next/*' --glob '!.trash/*' "supabaseServer\s+as\s+supabase" . || true

ok "Supabase import normalization complete."
