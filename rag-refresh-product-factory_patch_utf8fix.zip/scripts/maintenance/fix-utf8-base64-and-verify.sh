#!/usr/bin/env bash
set -euo pipefail

MODE="dry-run"
if [[ "${1:-}" == "--apply" ]]; then MODE="apply"; fi

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT_DIR"

say(){ printf "%b\n" "$*"; }
ok(){ say "✅ $*"; }
warn(){ say "⚠️  $*"; }

command -v rg >/dev/null || { echo "ripgrep required"; exit 1; }
command -v python3 >/dev/null || { echo "python3 required"; exit 1; }

HELPER_PATH="lib/encoding/base64.ts"

if [[ "$MODE" == "apply" ]]; then
  mkdir -p lib/encoding
  if [[ ! -f "$HELPER_PATH" ]]; then
cat > "$HELPER_PATH" <<'TS'
export function base64EncodeUtf8(input: string): string {
  const bytes = new TextEncoder().encode(input);
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary);
}

export function base64DecodeUtf8(base64: string): string {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}
TS
    ok "Created $HELPER_PATH"
  else
    ok "Helper exists: $HELPER_PATH"
  fi
else
  [[ -f "$HELPER_PATH" ]] && ok "Helper exists: $HELPER_PATH" || warn "Would create $HELPER_PATH"
fi

TARGET_DIRS=(app src components lib vscode-extension/src vscode-extension/webview)
INCLUDE=()
for d in "${TARGET_DIRS[@]}"; do [[ -d "$d" ]] && INCLUDE+=(--glob "$d/**"); done

FILES=$(rg -l --hidden   --glob '!**/node_modules/**'   --glob '!**/.next/**'   --glob '!**/dist/**'   --glob '!**/build/**'   "${INCLUDE[@]}"   '\bbtoa\(|\batob\(' || true)

if [[ -z "$FILES" ]]; then
  ok "No btoa()/atob() usage found in target dirs."
  exit 0
fi

say "Found files:"
echo "$FILES"

[[ "$MODE" != "apply" ]] && { ok "Dry run complete."; exit 0; }

mkdir -p .patch-backups/utf8-base64

for f in $FILES; do
  cp "$f" ".patch-backups/utf8-base64/$(echo "$f" | tr '/' '__')"
  perl -0777 -i -pe 's/\bbtoa\(/base64EncodeUtf8(/g; s/\batob\(/base64DecodeUtf8(/g' "$f"
done

ok "UTF-8/base64 hardening applied."
