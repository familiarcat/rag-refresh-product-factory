#!/usr/bin/env bash
set -euo pipefail

say(){ printf "%b\n" "$*"; }
warn(){ say "⚠️  $*"; }

PATCH_ZIPS=("$@")

[[ -d .next ]] && rm -rf .next

for z in "${PATCH_ZIPS[@]}"; do
  [[ -f "$z" ]] || { warn "Patch not found: $z"; continue; }
  say "Applying patch overlay: $z"
  unzip -oq "$z"
done

bash scripts/maintenance/fix-utf8-base64-and-verify.sh --apply || warn "UTF-8 hardening failed; continuing"

say "Upgrade + verification complete."
