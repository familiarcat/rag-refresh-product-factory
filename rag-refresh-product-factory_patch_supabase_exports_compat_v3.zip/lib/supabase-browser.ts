/**
 * Legacy entrypoint: '@/lib/supabase-browser'
 */
export { supabaseBrowser } from './supabase';
