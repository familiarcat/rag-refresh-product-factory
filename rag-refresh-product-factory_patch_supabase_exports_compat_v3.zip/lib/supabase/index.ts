/**
 * Supabase client + auth helpers (single source of truth).
 *
 * This file intentionally provides BOTH:
 *  - New API:   supabaseServer / supabaseBrowser
 *  - Compat API: supabase, checkPermission, logAudit, ApiKey, AuthProfile, etc.
 *
 * Many parts of the codebase import from:
 *  - '@/lib/supabase-server' (legacy)
 *  - '@/lib/supabase-browser' (legacy)
 *  - '@/lib/supabase' or '../supabase' (barrel)
 */

import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '@/types/supabase';

function mustGetEnv(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env var: ${name}`);
  return v;
}

const SUPABASE_URL =
  process.env.SUPABASE_URL ||
  process.env.NEXT_PUBLIC_SUPABASE_URL ||
  '';

// Service role is server-only. If missing (e.g. local dev), fall back to anon so builds don't explode.
const SERVICE_ROLE_KEY =
  process.env.SUPABASE_SERVICE_ROLE_KEY ||
  process.env.SUPABASE_SERVICE_KEY ||
  '';

const ANON_KEY =
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  process.env.SUPABASE_ANON_KEY ||
  '';

function createServerClient(): SupabaseClient<Database> {
  if (!SUPABASE_URL) throw new Error('Missing SUPABASE_URL / NEXT_PUBLIC_SUPABASE_URL');
  const key = SERVICE_ROLE_KEY || ANON_KEY;
  if (!key) throw new Error('Missing SUPABASE_SERVICE_ROLE_KEY (or NEXT_PUBLIC_SUPABASE_ANON_KEY fallback)');

  return createClient<Database>(SUPABASE_URL, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { 'X-Client-Info': 'rag-refresh-product-factory/server' } },
  });
}

function createBrowserClient(): SupabaseClient<Database> {
  if (!SUPABASE_URL) throw new Error('Missing NEXT_PUBLIC_SUPABASE_URL / SUPABASE_URL');
  if (!ANON_KEY) throw new Error('Missing NEXT_PUBLIC_SUPABASE_ANON_KEY');

  return createClient<Database>(SUPABASE_URL, ANON_KEY, {
    auth: { persistSession: true, autoRefreshToken: true },
    global: { headers: { 'X-Client-Info': 'rag-refresh-product-factory/browser' } },
  });
}

// --- Primary exports ---
export const supabaseServer = createServerClient();
export const supabaseBrowser = createBrowserClient();

// --- Compat exports (legacy code expects these) ---
// "supabase" historically meant the server client in this repo.
export const supabase = supabaseServer;

export interface AuthProfile {
  id: string;
  email?: string | null;
  role?: string | null;
  created_at?: string | null;
  [k: string]: unknown;
}

export interface ApiKey {
  id: string;
  user_id: string;
  name?: string | null;
  key_hash?: string | null;
  revoked_at?: string | null;
  created_at?: string | null;
  [k: string]: unknown;
}

/**
 * RPC wrapper used by lib/auth/middleware.ts and others.
 * Uses RPC 'check_permission' when available; otherwise returns false.
 */
export async function checkPermission(args: {
  userId: string;
  permission: string;
  projectId?: string | null;
}): Promise<boolean> {
  try {
    const { data, error } = await supabaseServer.rpc('check_permission' as never, {
      p_user_id: args.userId,
      p_permission: args.permission,
      p_project_id: args.projectId ?? null,
    } as never);
    if (error) return false;
    return Boolean(data);
  } catch {
    return false;
  }
}

/**
 * Basic audit logger. If your table/function differs, this will no-op safely.
 */
export async function logAudit(event: {
  userId?: string | null;
  action: string;
  resource?: string | null;
  metadata?: Record<string, unknown> | null;
}): Promise<void> {
  try {
    // Prefer inserting into audit_logs if present.
    await supabaseServer
      .from('audit_logs' as never)
      .insert({
        user_id: event.userId ?? null,
        action: event.action,
        resource: event.resource ?? null,
        metadata: event.metadata ?? null,
      } as never);
  } catch {
    // No-op: audit table might not exist in some environments
  }
}

export async function checkSupabaseConnection(): Promise<{ ok: boolean; error?: string }> {
  try {
    const { error } = await supabaseServer.from('projects' as never).select('*', { count: 'exact', head: true } as never);
    if (error) return { ok: false, error: error.message };
    return { ok: true };
  } catch (e: any) {
    return { ok: false, error: e?.message ?? 'unknown error' };
  }
}

export async function getDatabaseStats(): Promise<Record<string, unknown>> {
  // Keep it generic so it compiles even if tables differ.
  try {
    const { count } = await supabaseServer
      .from('projects' as never)
      .select('*', { count: 'exact', head: true } as never);
    return { projectsCount: count ?? 0 };
  } catch {
    return { projectsCount: 0 };
  }
}
