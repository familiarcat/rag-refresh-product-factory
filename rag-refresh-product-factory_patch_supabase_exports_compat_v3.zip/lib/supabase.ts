/**
 * Canonical barrel: '@/lib/supabase'
 */
export * from './supabase';
