/**
 * Legacy entrypoint: many files import from '@/lib/supabase-server'.
 * Keep this as a thin re-export to the canonical barrel: '@/lib/supabase'
 */
export {
  supabaseServer,
  supabase, // compat alias
  checkPermission,
  logAudit,
  checkSupabaseConnection,
  getDatabaseStats,
  type AuthProfile,
  type ApiKey,
} from './supabase';
