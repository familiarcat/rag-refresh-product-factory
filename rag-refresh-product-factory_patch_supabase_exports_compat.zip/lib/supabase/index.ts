/**
 * Supabase entrypoint (single import surface)
 *
 * Goal: all app/server code can import from "@/lib/supabase" and receive
 * a correctly-typed server or browser client, plus a few legacy/compat exports.
 *
 * NOTE:
 * - `supabase` is exported as an alias of `supabaseServer` for backward compat.
 * - Prefer importing `supabaseServer` or `supabaseBrowser` explicitly.
 */

import { supabaseServer } from "./supabase-server";
import { supabaseBrowser } from "./supabase-browser";
import type { Database } from "@/types/supabase";

// Primary exports
export { supabaseServer, supabaseBrowser };
export type { Database };

/**
 * Back-compat export: many modules historically imported `{ supabase }`
 * from "@/lib/supabase". In server contexts (API routes, middleware),
 * this should point at the server client.
 */
export const supabase = supabaseServer;

/**
 * Back-compat types/exports used by older auth middleware.
 * These are implemented in a minimal, schema-tolerant way so builds don't break
 * when DB types are not yet generated locally.
 */

export type AuthProfile = {
  id: string;
  email?: string | null;
  display_name?: string | null;
  role?: string | null;
  [key: string]: unknown;
};

/**
 * Check whether a user has a permission (optionally scoped to a project).
 *
 * Expected DB function (recommended):
 *   RPC: check_permission(p_user_id uuid/text, p_permission text, p_project_id uuid/text nullable)
 *
 * Returns boolean (or truthy).
 */
export async function checkPermission(args: {
  userId: string;
  permission: string;
  projectId?: string | null;
}): Promise<boolean> {
  const { userId, permission, projectId = null } = args;

  // We intentionally cast to `any` to avoid "never" issues when generated types
  // are missing or out-of-date.
  const client: any = supabaseServer as any;

  const { data, error } = await client.rpc("check_permission", {
    p_user_id: userId,
    p_permission: permission,
    p_project_id: projectId,
  });

  if (error) {
    // Default to false on error.
    console.warn("[checkPermission] RPC error:", error?.message ?? error);
    return false;
  }
  return Boolean(data);
}

/**
 * Log an audit entry (best-effort).
 *
 * Recommended table:
 *   audit_logs(user_id, action, project_id, context, created_at)
 *
 * If the table doesn't exist, this will no-op without failing the request.
 */
export async function logAudit(entry: {
  userId: string;
  action: string;
  projectId?: string | null;
  context?: Record<string, unknown> | null;
}): Promise<void> {
  const { userId, action, projectId = null, context = null } = entry;
  const client: any = supabaseServer as any;

  try {
    const { error } = await client.from("audit_logs").insert({
      user_id: userId,
      action,
      project_id: projectId,
      context,
    });
    if (error) {
      // Do not throw: audit logging should not break main flow.
      console.warn("[logAudit] insert error:", error?.message ?? error);
    }
  } catch (e) {
    console.warn("[logAudit] unavailable:", e);
  }
}
