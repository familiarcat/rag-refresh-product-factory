#!/usr/bin/env bash
set -e

echo "🔧 Normalizing Supabase imports..."

rg -l "from '@/lib/supabase'" | while read -r file; do
  sed -i '' "s@from '@/lib/supabase'@from '@/lib/supabase-server'@g" "$file"
done

rg -l "from '@/lib/supabase-server'" | while read -r file; do
  sed -i '' "s/import { supabaseServer as supabase }/import { supabase }/g" "$file"
done

echo "✅ Supabase imports normalized"
