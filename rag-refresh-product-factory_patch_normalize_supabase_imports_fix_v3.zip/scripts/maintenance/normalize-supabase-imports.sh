#!/usr/bin/env bash
set -euo pipefail

ok(){ printf "✅ %s\n" "$*"; }
warn(){ printf "⚠️  %s\n" "$*"; }

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.. && pwd)"
cd "$ROOT"

if ! command -v rg >/dev/null 2>&1; then
  warn "rg (ripgrep) not found; cannot normalize imports."
  exit 0
fi

ok "Normalizing Supabase imports (macOS/Linux safe; no sed)..."

# Iterate files safely (no command-substitution argument explosion)
rg -l --glob '!*node_modules/*' --glob '!*\.next/*' --glob '!.trash/*' "from ['\"]@/lib/supabase['\"]" . 2>/dev/null \
| while IFS= read -r f; do
    [[ -f "$f" ]] || continue
    perl -0777 -pi -e 's/from\s+("|\x27)@\/lib\/supabase\1/from $1@\/lib\/supabase-server$1/g' "$f"
  done

rg -l --glob '!*node_modules/*' --glob '!*\.next/*' --glob '!.trash/*' "supabaseServer\s+as\s+supabase" . 2>/dev/null \
| while IFS= read -r f; do
    [[ -f "$f" ]] || continue
    perl -0777 -pi -e 's/import\s*\{\s*supabaseServer\s+as\s+supabase\s*\}/import { supabase }/g' "$f"
  done

ok "Quick report (should be empty):"
rg -n --glob '!*node_modules/*' --glob '!*\.next/*' --glob '!.trash/*' "from ['\"]@/lib/supabase['\"]" . || true
rg -n --glob '!*node_modules/*' --glob '!*\.next/*' --glob '!.trash/*' "supabaseServer\s+as\s+supabase" . || true

ok "Supabase import normalization complete."
