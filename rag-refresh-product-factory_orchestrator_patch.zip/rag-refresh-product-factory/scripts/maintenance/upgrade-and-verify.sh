\
#!/usr/bin/env bash
# scripts/maintenance/upgrade-and-verify.sh
#
# One-button upgrade for AlexAI product-factory repos:
# 1) Overlay an "enhancements patch" zip into the repo (non-destructive: only overwrites patch files)
# 2) Run UTF-8 base64 hardening pass (dry-run then apply) to prevent VS Code WebView ByteString crashes
# 3) Run best-effort verification: env check, lint, typecheck, build (root + vscode-extension)
#
# Usage:
#   bash scripts/maintenance/upgrade-and-verify.sh /path/to/enhancements_patch.zip
#
set -euo pipefail

ZIP="${1:-}"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT_DIR"

say() { printf "%b\n" "$*"; }
ok()  { say "✅ $*"; }
warn(){ say "⚠️  $*"; }
err() { say "❌ $*"; exit 1; }

command -v unzip >/dev/null 2>&1 || err "unzip required"
command -v node  >/dev/null 2>&1 || err "node required"
command -v npm   >/dev/null 2>&1 || err "npm required"

if [[ -z "$ZIP" ]]; then
  err "Usage: bash scripts/maintenance/upgrade-and-verify.sh <enhancements_patch.zip>"
fi
if [[ ! -f "$ZIP" ]]; then
  err "Patch zip not found: $ZIP"
fi

# Safety checks: refuse patch zips containing build/cache artifacts
if unzip -Z1 "$ZIP" | grep -E '(^|/)(\.git/|node_modules/|\.next/|dist/|build/|coverage/)' >/dev/null 2>&1; then
  err "Patch zip contains build/cache artifacts (.git/node_modules/.next/dist/etc). Refusing."
fi

ok "Applying patch overlay: $ZIP"
unzip -o "$ZIP" >/dev/null

ok "Patch overlay applied."

run_if_script_exists() {
  local dir="$1"
  local script="$2"
  if [[ -f "$dir/package.json" ]]; then
    node -e "
      const p=require('./$dir/package.json');
      process.exit(p.scripts && p.scripts['$script'] ? 0 : 1);
    " >/dev/null 2>&1 && {
      ok "Running: npm -C $dir run $script"
      npm -C "$dir" run "$script"
      return 0
    }
  fi
  warn "No script '$script' in $dir/package.json (skipping)"
  return 0
}

# UTF-8 base64 hardening pass (only if present)
if [[ -f "scripts/maintenance/fix-utf8-base64-and-verify.sh" ]]; then
  ok "Running UTF-8 base64 hardening (dry-run)…"
  bash scripts/maintenance/fix-utf8-base64-and-verify.sh || true
  ok "Applying UTF-8 base64 hardening…"
  bash scripts/maintenance/fix-utf8-base64-and-verify.sh --apply
else
  warn "Missing scripts/maintenance/fix-utf8-base64-and-verify.sh (skipping hardening)"
fi

# Install deps (best effort)
if [[ -f "package.json" ]]; then
  ok "Installing root deps…"
  npm install
else
  warn "No root package.json found (skipping npm install)"
fi

# Root verification (best effort)
run_if_script_exists "." "check:env" || true
run_if_script_exists "." "lint" || true
run_if_script_exists "." "typecheck" || true
run_if_script_exists "." "build" || true

# VS Code extension verification (best effort)
if [[ -d "vscode-extension" ]]; then
  ok "Installing vscode-extension deps…"
  npm -C vscode-extension install || true
  run_if_script_exists "vscode-extension" "lint" || true
  run_if_script_exists "vscode-extension" "typecheck" || true
  run_if_script_exists "vscode-extension" "build" || true
else
  warn "No vscode-extension/ directory found (skipping extension checks)"
fi

ok "Upgrade + verification complete."
